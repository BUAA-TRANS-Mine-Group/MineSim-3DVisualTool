#include <ros/ros.h>
#include <iostream>
#include <memory>
#include <msgs/vehicle_info.h>
#include <msgs/decision_info.h>
#include <msgs/control_info.h>
#include <msgs/sensor_info.h>
#include <msgs/map_track_info.h>
#include "read_path.h"
#define frequency 20

int count_plan;
int count_map0, count_map1, count_map2, count_map3; //需要按路径数量增加
int count_map4, count_map5, count_map6, count_map7;
int count_map8, count_map9, count_map10, count_map11;

msgs::map_track_info map_path_0;  //需要按路径数量增加
msgs::map_track_info map_path_1;
msgs::map_track_info map_path_2;
msgs::map_track_info map_path_3;

msgs::map_track_info map_path_4;  
msgs::map_track_info map_path_5;
msgs::map_track_info map_path_6;
msgs::map_track_info map_path_7;

msgs::map_track_info map_path_8;  
msgs::map_track_info map_path_9;
msgs::map_track_info map_path_10;
msgs::map_track_info map_path_11;

bool trac_clear0, trac_clear1, trac_clear2, trac_clear3;  //需要按路径数量增加
bool trac_clear4, trac_clear5, trac_clear6, trac_clear7;  //需要按路径数量增加
bool trac_clear8, trac_clear9, trac_clear10, trac_clear11;  //需要按路径数量增加
double** track_plan;

double** map_center0; //需要按路径数量增加 ,在Maptrack_infoCallback函数中被使用
double** map_center1;
double** map_center2;
double** map_center3;

double** map_center4; 
double** map_center5;
double** map_center6;
double** map_center7;

double** map_center8; 
double** map_center9;
double** map_center10;
double** map_center11;

int infocla_count0 = 0, infocla_count1 = 0, infocla_count2 = 0, infocla_count3 = 0;  //需要按路径数量增加
int infocla_count4 = 0, infocla_count5 = 0, infocla_count6 = 0, infocla_count7 = 0;
int infocla_count8 = 0, infocla_count9 = 0, infocla_count10 = 0, infocla_count11 = 0;

int infopub_count0 = 0, infopub_count1 = 0, infopub_count2 = 0, infopub_count3 = 0;  //需要按路径数量增加
int infopub_count4 = 0, infopub_count5 = 0, infopub_count6 = 0, infopub_count7 = 0;
int infopub_count8 = 0, infopub_count9 = 0, infopub_count10 = 0, infopub_count11 = 0;

double** track_clear(int track_count, bool& trac_clear){
    double** track_;
    track_ = new double*[track_count];//行

    for (int k = 0; k < track_count; k++) 
    {
        track_[k] = new double[4];//4列 0x 1y 2预留 3航向
    } 
    trac_clear = true;
    return track_;
}


void Vehicle_infoCallback0(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state0.now_speed = msg->speed; 
    vec_state0.now_posy = msg->posy;
    vec_state0.now_posx = msg->posx;
    vec_state0.now_head = msg->head;
    // cout<<"vec_state.now_posx: "<<vec_state.now_posy<<endl;
}

void Vehicle_infoCallback1(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state1.now_speed = msg->speed; 
    vec_state1.now_posy = msg->posy;
    vec_state1.now_posx = msg->posx;
    vec_state1.now_head = msg->head;
    // cout<<"vec_state.now_posx: "<<vec_state.now_posy<<endl;
}

void Vehicle_infoCallback2(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state2.now_speed = msg->speed; 
    vec_state2.now_posy = msg->posy;
    vec_state2.now_posx = msg->posx;
    vec_state2.now_head = msg->head;
    // cout<<"vec_state.now_posx: "<<vec_state.now_posy<<endl;
}

void Vehicle_infoCallback3(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state3.now_speed = msg->speed; 
    vec_state3.now_posy = msg->posy;
    vec_state3.now_posx = msg->posx;
    vec_state3.now_head = msg->head;
    // cout<<"vec_state.now_posx: "<<vec_state.now_posy<<endl;
}

void Vehicle_infoCallback4(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state4.now_speed = msg->speed; 
    vec_state4.now_posy = msg->posy;
    vec_state4.now_posx = msg->posx;
    vec_state4.now_head = msg->head;
}

void Vehicle_infoCallback5(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state5.now_speed = msg->speed; 
    vec_state5.now_posy = msg->posy;
    vec_state5.now_posx = msg->posx;
    vec_state5.now_head = msg->head;
}

void Vehicle_infoCallback6(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state6.now_speed = msg->speed; 
    vec_state6.now_posy = msg->posy;
    vec_state6.now_posx = msg->posx;
    vec_state6.now_head = msg->head;
}

void Vehicle_infoCallback7(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state7.now_speed = msg->speed; 
    vec_state7.now_posy = msg->posy;
    vec_state7.now_posx = msg->posx;
    vec_state7.now_head = msg->head;
}

void Vehicle_infoCallback8(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state8.now_speed = msg->speed; 
    vec_state8.now_posy = msg->posy;
    vec_state8.now_posx = msg->posx;
    vec_state8.now_head = msg->head;
}

void Vehicle_infoCallback9(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state9.now_speed = msg->speed; 
    vec_state9.now_posy = msg->posy;
    vec_state9.now_posx = msg->posx;
    vec_state9.now_head = msg->head;
}

void Vehicle_infoCallback10(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state10.now_speed = msg->speed; 
    vec_state10.now_posy = msg->posy;
    vec_state10.now_posx = msg->posx;
    vec_state10.now_head = msg->head;
}

void Vehicle_infoCallback11(const msgs::vehicle_info::ConstPtr& msg)  //需要按路径数量增加并修改函数中的变量名
{
    vec_state11.now_speed = msg->speed; 
    vec_state11.now_posy = msg->posy;
    vec_state11.now_posx = msg->posx;
    vec_state11.now_head = msg->head;
}



void Maptrack_infoCallback0(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_0 = *map_path;   //需要改变量名  map_path_0
    count_map0 = map_path_0.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info0.map_center.centerx = map_path_0.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info0.map_center.centery = map_path_0.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info0.map_center.centerh = map_path_0.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear0 = false;  //需要改变量名  trac_clear0
    map_center0 =track_clear(count_map0, trac_clear0); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map0 != 0 && infocla_count0 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear0){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map0;i++){  //需要改变量名  count_map0
                map_center0[i][0] = map_path_info0.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center0[i][1] = map_path_info0.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center0[i][3] = map_path_info0.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count0 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback1(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_1 = *map_path;   //需要改变量名  map_path_0
    count_map1 = map_path_1.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info1.map_center.centerx = map_path_1.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info1.map_center.centery = map_path_1.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info1.map_center.centerh = map_path_1.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear1 = false;  //需要改变量名  trac_clear0
    map_center1 =track_clear(count_map1, trac_clear1); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map1 != 0 && infocla_count1 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear1){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map1;i++){  //需要改变量名  count_map0
                map_center1[i][0] = map_path_info1.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center1[i][1] = map_path_info1.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center1[i][3] = map_path_info1.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count1 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback2(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_2 = *map_path;   //需要改变量名  map_path_0
    count_map2 = map_path_2.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info2.map_center.centerx = map_path_2.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info2.map_center.centery = map_path_2.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info2.map_center.centerh = map_path_2.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear2 = false;  //需要改变量名  trac_clear0
    map_center2 =track_clear(count_map2, trac_clear2); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map2 != 0 && infocla_count2 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear2){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map2;i++){  //需要改变量名  count_map0
                map_center2[i][0] = map_path_info2.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center2[i][1] = map_path_info2.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center2[i][3] = map_path_info2.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count2 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback3(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_3 = *map_path;   //需要改变量名  map_path_0
    count_map3 = map_path_3.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info3.map_center.centerx = map_path_3.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info3.map_center.centery = map_path_3.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info3.map_center.centerh = map_path_3.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear3 = false;  //需要改变量名  trac_clear0
    map_center3 =track_clear(count_map3, trac_clear3); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map3 != 0 && infocla_count3 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear3){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map3;i++){  //需要改变量名  count_map0
                map_center3[i][0] = map_path_info3.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center3[i][1] = map_path_info3.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center3[i][3] = map_path_info3.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count3 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback4(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_4 = *map_path;   //需要改变量名  map_path_0
    count_map4 = map_path_4.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info4.map_center.centerx = map_path_4.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info4.map_center.centery = map_path_4.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info4.map_center.centerh = map_path_4.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear4 = false;  //需要改变量名  trac_clear0
    map_center4 =track_clear(count_map4, trac_clear4); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map4 != 0 && infocla_count4 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear4){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map4;i++){  //需要改变量名  count_map0
                map_center4[i][0] = map_path_info4.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center4[i][1] = map_path_info4.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center4[i][3] = map_path_info4.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count4 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback5(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_5 = *map_path;   //需要改变量名  map_path_0
    count_map5 = map_path_5.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info5.map_center.centerx = map_path_5.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info5.map_center.centery = map_path_5.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info5.map_center.centerh = map_path_5.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear5 = false;  //需要改变量名  trac_clear0
    map_center5 =track_clear(count_map5, trac_clear5); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map5 != 0 && infocla_count5 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear5){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map5;i++){  //需要改变量名  count_map0
                map_center5[i][0] = map_path_info5.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center5[i][1] = map_path_info5.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center5[i][3] = map_path_info5.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count5 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback6(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_6 = *map_path;   //需要改变量名  map_path_0
    count_map6 = map_path_6.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info6.map_center.centerx = map_path_6.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info6.map_center.centery = map_path_6.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info6.map_center.centerh = map_path_6.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear6 = false;  //需要改变量名  trac_clear0
    map_center6 =track_clear(count_map6, trac_clear6); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map6 != 0 && infocla_count6 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear6){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map6;i++){  //需要改变量名  count_map0
                map_center6[i][0] = map_path_info6.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center6[i][1] = map_path_info6.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center6[i][3] = map_path_info6.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count6 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback7(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_7 = *map_path;   //需要改变量名  map_path_0
    count_map7 = map_path_7.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info7.map_center.centerx = map_path_7.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info7.map_center.centery = map_path_7.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info7.map_center.centerh = map_path_7.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear7 = false;  //需要改变量名  trac_clear0
    map_center7 =track_clear(count_map7, trac_clear7); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map7 != 0 && infocla_count7 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear7){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map7;i++){  //需要改变量名  count_map0
                map_center7[i][0] = map_path_info7.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center7[i][1] = map_path_info7.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center7[i][3] = map_path_info7.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count7 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback8(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_8 = *map_path;   //需要改变量名  map_path_0
    count_map8 = map_path_8.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info8.map_center.centerx = map_path_8.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info8.map_center.centery = map_path_8.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info8.map_center.centerh = map_path_8.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear8 = false;  //需要改变量名  trac_clear0
    map_center8 =track_clear(count_map8, trac_clear8); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map8 != 0 && infocla_count8 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear8){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map8;i++){  //需要改变量名  count_map0
                map_center8[i][0] = map_path_info8.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center8[i][1] = map_path_info8.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center8[i][3] = map_path_info8.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count8 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback9(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_9 = *map_path;   //需要改变量名  map_path_0
    count_map9 = map_path_9.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info9.map_center.centerx = map_path_9.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info9.map_center.centery = map_path_9.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info9.map_center.centerh = map_path_9.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear9 = false;  //需要改变量名  trac_clear0
    map_center9 =track_clear(count_map9, trac_clear9); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map9 != 0 && infocla_count9 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear9){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map9;i++){  //需要改变量名  count_map0
                map_center9[i][0] = map_path_info9.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center9[i][1] = map_path_info9.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center9[i][3] = map_path_info9.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count9 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback10(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_10 = *map_path;   //需要改变量名  map_path_0
    count_map10 = map_path_10.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info10.map_center.centerx = map_path_10.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info10.map_center.centery = map_path_10.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info10.map_center.centerh = map_path_10.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear10 = false;  //需要改变量名  trac_clear0
    map_center10 =track_clear(count_map10, trac_clear10); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map10 != 0 && infocla_count10 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear10){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map10;i++){  //需要改变量名  count_map0
                map_center10[i][0] = map_path_info10.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center10[i][1] = map_path_info10.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center10[i][3] = map_path_info10.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count10 ++; //需要改变量名  infocla_count0
   }
}

void Maptrack_infoCallback11(const msgs::map_track_info::ConstPtr& map_path)  //需要按路径数量增加并修改函数中的变量名
{
    map_path_11 = *map_path;   //需要改变量名  map_path_0
    count_map11 = map_path_11.map_center_x.size();   //需要改变量名  count_map0 map_path_0
    map_path_info11.map_center.centerx = map_path_11.map_center_x;  //需要改变量名  map_path_info0 map_path_0
    map_path_info11.map_center.centery = map_path_11.map_center_y;  //需要改变量名  map_path_info0 map_path_0
    map_path_info11.map_center.centerh = map_path_11.map_center_h;  //需要改变量名  map_path_info0 map_path_0

    trac_clear11 = false;  //需要改变量名  trac_clear0
    map_center11 =track_clear(count_map11, trac_clear11); //需要改变量名  map_center0 count_map0 trac_clear0

    if(count_map11 != 0 && infocla_count11 < 2){  //需要改变量名  count_map0 infocla_count0
        if(trac_clear11){       //需要改变量名  trac_clear0
            for(int i = 0;i<count_map11;i++){  //需要改变量名  count_map0
                map_center11[i][0] = map_path_info11.map_center.centerx[i];  //需要改变量名  map_center0 map_path_info0
                map_center11[i][1] = map_path_info11.map_center.centery[i];  //需要改变量名  map_center0 map_path_info0
                map_center11[i][3] = map_path_info11.map_center.centerh[i];  //需要改变量名  map_center0 map_path_info0
            }
        }
        infocla_count11 ++; //需要改变量名  infocla_count0
   }
}

void Decision_infoCallback(const msgs::decision_info::ConstPtr& msg)
{
     decision_info.desire_gear = msg->dec_gear;
     decision_info.desire_speed = msg->dec_speed;        
}

void Control_infoCallback(const msgs::control_info::ConstPtr& msg)
{
     control_info.now_key = msg->now_point;
     control_info.pre_key = msg->pre_point;
     control_info.lat_erro = msg->lat_erro;     
}


int main(int argc, char** argv)
{

    ros::init(argc, argv, "rviz_display");
    ros::NodeHandle nh_private("~");
    ros::NodeHandle nh;
    ros::Rate loop_rate(frequency);
    ros::Time now_time;
    string child_frame_id="base_drive";

    //-----------路径文件发布----------//
    // read_gps(nh_private);
    // nh_private.getParam("frame_id", frame_id_);
    frame_id_ = "tracksim_pub";
    ros::Subscriber Maptrack_info_sub0 = nh.subscribe("/map_track0", 1000, &Maptrack_infoCallback0); //需要按路径数量增加
    ros::Subscriber Maptrack_info_sub1 = nh.subscribe("/map_track1", 1000, &Maptrack_infoCallback1);
    ros::Subscriber Maptrack_info_sub2 = nh.subscribe("/map_track2", 1000, &Maptrack_infoCallback2);
    ros::Subscriber Maptrack_info_sub3 = nh.subscribe("/map_track3", 1000, &Maptrack_infoCallback3);

    ros::Subscriber Maptrack_info_sub4 = nh.subscribe("/map_track4", 1000, &Maptrack_infoCallback4); 
    ros::Subscriber Maptrack_info_sub5 = nh.subscribe("/map_track5", 1000, &Maptrack_infoCallback5);
    ros::Subscriber Maptrack_info_sub6 = nh.subscribe("/map_track6", 1000, &Maptrack_infoCallback6);
    ros::Subscriber Maptrack_info_sub7 = nh.subscribe("/map_track7", 1000, &Maptrack_infoCallback7);

    ros::Subscriber Maptrack_info_sub8 = nh.subscribe("/map_track8", 1000, &Maptrack_infoCallback8); 
    ros::Subscriber Maptrack_info_sub9 = nh.subscribe("/map_track9", 1000, &Maptrack_infoCallback9);
    ros::Subscriber Maptrack_info_sub10 = nh.subscribe("/map_track10", 1000, &Maptrack_infoCallback10);
    ros::Subscriber Maptrack_info_sub11 = nh.subscribe("/map_track11", 1000, &Maptrack_infoCallback11);

    //以下三行需要按路径数量增加
    ros::Publisher track_pub_0 = nh_private.advertise<nav_msgs::Path>("/GPS_track0",1, true);//路径点发布
    nav_msgs::Path path_track0;//原始轨迹点发布消息定义
    path_track0.header.frame_id=frame_id_;

    ros::Publisher track_pub_1 = nh_private.advertise<nav_msgs::Path>("/GPS_track1",1, true);//路径点发布
    nav_msgs::Path path_track1;//原始轨迹点发布消息定义
    path_track1.header.frame_id=frame_id_;

    ros::Publisher track_pub_2 = nh_private.advertise<nav_msgs::Path>("/GPS_track2",1, true);//路径点发布
    nav_msgs::Path path_track2;//原始轨迹点发布消息定义
    path_track2.header.frame_id=frame_id_;

    ros::Publisher track_pub_3 = nh_private.advertise<nav_msgs::Path>("/GPS_track3",1, true);//路径点发布
    nav_msgs::Path path_track3;//原始轨迹点发布消息定义
    path_track3.header.frame_id=frame_id_;

    ros::Publisher track_pub_4 = nh_private.advertise<nav_msgs::Path>("/GPS_track4",1, true);//路径点发布
    nav_msgs::Path path_track4;//原始轨迹点发布消息定义
    path_track4.header.frame_id=frame_id_;

    ros::Publisher track_pub_5 = nh_private.advertise<nav_msgs::Path>("/GPS_track5",1, true);//路径点发布
    nav_msgs::Path path_track5;//原始轨迹点发布消息定义
    path_track5.header.frame_id=frame_id_;

    ros::Publisher track_pub_6 = nh_private.advertise<nav_msgs::Path>("/GPS_track6",1, true);//路径点发布
    nav_msgs::Path path_track6;//原始轨迹点发布消息定义
    path_track6.header.frame_id=frame_id_;

    ros::Publisher track_pub_7 = nh_private.advertise<nav_msgs::Path>("/GPS_track7",1, true);//路径点发布
    nav_msgs::Path path_track7;//原始轨迹点发布消息定义
    path_track7.header.frame_id=frame_id_;

    ros::Publisher track_pub_8 = nh_private.advertise<nav_msgs::Path>("/GPS_track8",1, true);//路径点发布
    nav_msgs::Path path_track8;//原始轨迹点发布消息定义
    path_track8.header.frame_id=frame_id_;

    ros::Publisher track_pub_9 = nh_private.advertise<nav_msgs::Path>("/GPS_track9",1, true);//路径点发布
    nav_msgs::Path path_track9;//原始轨迹点发布消息定义
    path_track9.header.frame_id=frame_id_;

    ros::Publisher track_pub_10 = nh_private.advertise<nav_msgs::Path>("/GPS_track10",1, true);//路径点发布
    nav_msgs::Path path_track10;//原始轨迹点发布消息定义
    path_track10.header.frame_id=frame_id_;

    ros::Publisher track_pub_11 = nh_private.advertise<nav_msgs::Path>("/GPS_track11",1, true);//路径点发布
    nav_msgs::Path path_track11;//原始轨迹点发布消息定义
    path_track11.header.frame_id=frame_id_;

    //-----------路径文件发布----------//
    //决策订阅
    ros::Subscriber decision_info_sub = nh.subscribe("/decision_result", 1000, &Decision_infoCallback);

    //控制订阅
    ros::Subscriber control_info_sub = nh.subscribe("/control_result", 1000, &Control_infoCallback);

    //接收车辆位置 需要按路径数量增加
    ros::Subscriber veh0_info_sub0 = nh.subscribe("/veh0_state", 1000, &Vehicle_infoCallback0);
    ros::Subscriber veh0_info_sub1 = nh.subscribe("/veh1_state", 1000, &Vehicle_infoCallback1);
    ros::Subscriber veh0_info_sub2 = nh.subscribe("/veh2_state", 1000, &Vehicle_infoCallback2);
    ros::Subscriber veh0_info_sub3 = nh.subscribe("/veh3_state", 1000, &Vehicle_infoCallback3);

    ros::Subscriber veh0_info_sub4 = nh.subscribe("/veh4_state", 1000, &Vehicle_infoCallback4);
    ros::Subscriber veh0_info_sub5 = nh.subscribe("/veh5_state", 1000, &Vehicle_infoCallback5);
    ros::Subscriber veh0_info_sub6 = nh.subscribe("/veh6_state", 1000, &Vehicle_infoCallback6);
    ros::Subscriber veh0_info_sub7 = nh.subscribe("/veh7_state", 1000, &Vehicle_infoCallback7);

    ros::Subscriber veh0_info_sub8 = nh.subscribe("/veh8_state", 1000, &Vehicle_infoCallback8);
    ros::Subscriber veh0_info_sub9 = nh.subscribe("/veh9_state", 1000, &Vehicle_infoCallback9);
    ros::Subscriber veh0_info_sub10 = nh.subscribe("/veh10_state", 1000, &Vehicle_infoCallback10);
    ros::Subscriber veh0_info_sub11 = nh.subscribe("/veh11_state", 1000, &Vehicle_infoCallback11);
    

    //车辆发布  需要按路径数量增加
    visualization_msgs::Marker vehicle_marker_0_;
    ros::Publisher pubVehicle0 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec0",100, true);

    visualization_msgs::Marker vehicle_marker_1_;
    ros::Publisher pubVehicle1 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec1",100, true);

    visualization_msgs::Marker vehicle_marker_2_;
    ros::Publisher pubVehicle2 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec2",100, true);
    
    visualization_msgs::Marker vehicle_marker_3_;
    ros::Publisher pubVehicle3 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec3",100, true);

    visualization_msgs::Marker vehicle_marker_4_;
    ros::Publisher pubVehicle4 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec4",100, true);

    visualization_msgs::Marker vehicle_marker_5_;
    ros::Publisher pubVehicle5 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec5",100, true);

    visualization_msgs::Marker vehicle_marker_6_;
    ros::Publisher pubVehicle6 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec6",100, true);

    visualization_msgs::Marker vehicle_marker_7_;
    ros::Publisher pubVehicle7 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec7",100, true);

    visualization_msgs::Marker vehicle_marker_8_;
    ros::Publisher pubVehicle8 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec8",100, true);

    visualization_msgs::Marker vehicle_marker_9_;
    ros::Publisher pubVehicle9 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec9",100, true);

    visualization_msgs::Marker vehicle_marker_10_;
    ros::Publisher pubVehicle10 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec10",100, true);

    visualization_msgs::Marker vehicle_marker_11_;
    ros::Publisher pubVehicle11 = nh_private.advertise<visualization_msgs::Marker>("/drive_vec11",100, true);
    

    while(ros::ok())
    {

        now_time = ros::Time::now();
        //需要按路径数量增加并修改变量名称
        double now_x_0,now_y_0,now_yaw_0;
        double now_x_1,now_y_1,now_yaw_1;
        double now_x_2,now_y_2,now_yaw_2;
        double now_x_3,now_y_3,now_yaw_3;

        double now_x_4,now_y_4,now_yaw_4;
        double now_x_5,now_y_5,now_yaw_5;
        double now_x_6,now_y_6,now_yaw_6;
        double now_x_7,now_y_7,now_yaw_7;

        double now_x_8,now_y_8,now_yaw_8;
        double now_x_9,now_y_9,now_yaw_9;
        double now_x_10,now_y_10,now_yaw_10;
        double now_x_11,now_y_11,now_yaw_11;

        now_x_0 = vec_state0.now_posx;
        now_y_0 = vec_state0.now_posy;
        now_yaw_0 =  (vec_state0.now_head + 180) * D2R;

        now_x_1 = vec_state1.now_posx;
        now_y_1 = vec_state1.now_posy;
        now_yaw_1 =  (vec_state1.now_head + 180) * D2R;

        now_x_2 = vec_state2.now_posx;
        now_y_2 = vec_state2.now_posy;
        now_yaw_2 =  (vec_state2.now_head + 180) * D2R;

        now_x_3 = vec_state3.now_posx;
        now_y_3 = vec_state3.now_posy;
        now_yaw_3 =  (vec_state3.now_head + 180) * D2R;

        now_x_4 = vec_state4.now_posx;
        now_y_4 = vec_state4.now_posy;
        now_yaw_4 =  (vec_state4.now_head + 180) * D2R;

        now_x_5 = vec_state5.now_posx;
        now_y_5 = vec_state5.now_posy;
        now_yaw_5 =  (vec_state5.now_head + 180) * D2R;

        now_x_6 = vec_state6.now_posx;
        now_y_6 = vec_state6.now_posy;
        now_yaw_6 =  (vec_state6.now_head + 180) * D2R;

        now_x_7 = vec_state7.now_posx;
        now_y_7 = vec_state7.now_posy;
        now_yaw_7 =  (vec_state7.now_head + 180) * D2R;

        now_x_8 = vec_state8.now_posx;
        now_y_8 = vec_state8.now_posy;
        now_yaw_8 =  (vec_state8.now_head + 180) * D2R;

        now_x_9 = vec_state9.now_posx;
        now_y_9 = vec_state9.now_posy;
        now_yaw_9 =  (vec_state9.now_head + 180) * D2R;

        now_x_10 = vec_state10.now_posx;
        now_y_10 = vec_state10.now_posy;
        now_yaw_10 =  (vec_state10.now_head + 180) * D2R;

        now_x_11 = vec_state11.now_posx;
        now_y_11 = vec_state11.now_posy;
        now_yaw_11 =  (vec_state11.now_head + 180) * D2R;

        //------------------------路径文件发布--------------------//
        //需要按路径数量增加
        if(count_map0 != 0 && infopub_count0 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map0;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center0[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center0[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center"; 
                path_track0.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_0.publish(path_track0);  //需要改变量名  track_pub_0 path_track0
            }
            infopub_count0++;   //需要改变量名  infopub_count0
        }

        if(count_map1 != 0 && infopub_count1 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map1;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center1[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center1[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track1.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_1.publish(path_track1);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count1++;   //需要改变量名  infopub_count0
        }

        if(count_map2 != 0 && infopub_count2 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map2;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center2[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center2[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track2.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_2.publish(path_track2);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count2++;   //需要改变量名  infopub_count0
        }

        if(count_map3 != 0 && infopub_count3 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map3;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center3[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center3[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track3.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_3.publish(path_track3);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count3++;   //需要改变量名  infopub_count0
        }

        if(count_map4 != 0 && infopub_count4 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map4;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center4[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center4[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track4.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_4.publish(path_track4);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count4++;   //需要改变量名  infopub_count0
        }

        if(count_map5 != 0 && infopub_count5 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map5;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center5[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center5[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track5.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_5.publish(path_track5);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count5++;   //需要改变量名  infopub_count0
        }

        if(count_map6 != 0 && infopub_count6 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map6;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center6[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center6[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track6.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_6.publish(path_track6);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count6++;   //需要改变量名  infopub_count0
        }

        if(count_map7 != 0 && infopub_count7 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map7;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center7[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center7[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track7.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_7.publish(path_track7);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count7++;   //需要改变量名  infopub_count0
        }

        if(count_map8 != 0 && infopub_count8 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map8;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center8[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center8[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track8.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_8.publish(path_track8);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count8++;   //需要改变量名  infopub_count0
        }

        if(count_map9 != 0 && infopub_count9 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map9;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center9[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center9[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track9.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_9.publish(path_track9);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count9++;   //需要改变量名  infopub_count0
        }

        if(count_map10 != 0 && infopub_count10 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map10;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center10[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center10[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track10.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_10.publish(path_track10);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count10++;   //需要改变量名  infopub_count0
        }

        if(count_map11 != 0 && infopub_count11 < 1){  //需要改变量名  count_map0 infopub_count0
            for(long int i=0;i<count_map11;i++){    //需要改变量名  count_map0
                geometry_msgs::PoseStamped this_pose_stamped;
                this_pose_stamped.pose.position.x = map_center11[i][0]; //需要改变量名  map_center0
                this_pose_stamped.pose.position.y = map_center11[i][1]; //需要改变量名  map_center0
                this_pose_stamped.header.frame_id="track_center";
                path_track11.poses.push_back(this_pose_stamped); //需要改变量名  path_track0
                track_pub_11.publish(path_track11);   //需要改变量名  track_pub_0 path_track0
            }
            infopub_count11++;   //需要改变量名  infopub_count0
        }


        //需要按路径数量增加和修改变量名
        //车辆0发布
        if(1){
            static tf::TransformBroadcaster br0;
            tf::Transform my_transform0;
            tf::Quaternion q0;
            q0.setRPY(0,0,0);
            my_transform0.setRotation(q0);
            vehicle_marker_0_.header.frame_id = "vec_drive0";
            vehicle_marker_0_.header.stamp = ros::Time(0);
            vehicle_marker_0_.ns = "vehicle";
            vehicle_marker_0_.action = visualization_msgs::Marker::ADD;
            vehicle_marker_0_.id = 0;
            vehicle_marker_0_.type = visualization_msgs::Marker::MESH_RESOURCE; 
            string mesh_resource_0 = "package://rviz_simulation/model/Mining_Truck_v1_L1.123c6431771f-f361-4a1f-8727-590a5c800ce0/16747_Mining_Truck_v1.obj";
            vehicle_marker_0_.scale.x = 0.003;
            vehicle_marker_0_.scale.y = 0.003;
            vehicle_marker_0_.scale.z = 0.003;
            vehicle_marker_0_.color.r = 0.85;//1
            vehicle_marker_0_.color.g = 0.64;//0.5
            vehicle_marker_0_.color.b = 0.12;  //0
            vehicle_marker_0_.color.a = 1;
            vehicle_marker_0_.mesh_resource = mesh_resource_0;
            vehicle_marker_0_.pose.position.x = 0;
            vehicle_marker_0_.pose.position.y = 0;
            vehicle_marker_0_.pose.position.z = 0;
            geometry_msgs::Quaternion temp_q0 = tf::createQuaternionMsgFromYaw(now_yaw_0);
            vehicle_marker_0_.pose.orientation.x = temp_q0.x;
            vehicle_marker_0_.pose.orientation.y = temp_q0.y;
            vehicle_marker_0_.pose.orientation.z = temp_q0.z;
            vehicle_marker_0_.pose.orientation.w = temp_q0.w;
            pubVehicle0.publish(vehicle_marker_0_);
            my_transform0.setOrigin(tf::Vector3(now_x_0,now_y_0,0));
            br0.sendTransform(tf::StampedTransform(my_transform0,ros::Time::now(),"tracksim_pub","vec_drive0"));
        }

        //车辆1发布
        if(1){
            static tf::TransformBroadcaster br1;
            tf::Transform my_transform1;
            tf::Quaternion q1;
            q1.setRPY(0,0,0);
            my_transform1.setRotation(q1);
            vehicle_marker_1_.header.frame_id = "vec_drive1";
            vehicle_marker_1_.header.stamp = ros::Time(0);
            vehicle_marker_1_.ns = "vehicle";
            vehicle_marker_1_.action = visualization_msgs::Marker::ADD;
            vehicle_marker_1_.id = 1;
            vehicle_marker_1_.type = visualization_msgs::Marker::MESH_RESOURCE; 
            string mesh_resource_1 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";
            vehicle_marker_1_.scale.x = 0.003;
            vehicle_marker_1_.scale.y = 0.003;
            vehicle_marker_1_.scale.z = 0.003;
            vehicle_marker_1_.color.r = 0.85;//1
            vehicle_marker_1_.color.g = 0.64;//0.5
            vehicle_marker_1_.color.b = 0.12;  //0
            vehicle_marker_1_.color.a = 1;
            vehicle_marker_1_.mesh_resource = mesh_resource_1;
            vehicle_marker_1_.pose.position.x = 0;
            vehicle_marker_1_.pose.position.y = 0;
            vehicle_marker_1_.pose.position.z = 0;
            geometry_msgs::Quaternion temp_q1 = tf::createQuaternionMsgFromYaw(now_yaw_1);
            vehicle_marker_1_.pose.orientation.x = temp_q1.x;
            vehicle_marker_1_.pose.orientation.y = temp_q1.y;
            vehicle_marker_1_.pose.orientation.z = temp_q1.z;
            vehicle_marker_1_.pose.orientation.w = temp_q1.w;
            pubVehicle1.publish(vehicle_marker_1_);
            my_transform1.setOrigin(tf::Vector3(now_x_1,now_y_1,0));
            br1.sendTransform(tf::StampedTransform(my_transform1,ros::Time::now(),"tracksim_pub","vec_drive1"));
        }

        //车辆2发布
        if(1){
            static tf::TransformBroadcaster br2;
            tf::Transform my_transform2;
            tf::Quaternion q2;
            q2.setRPY(0,0,0);
            my_transform2.setRotation(q2);
            vehicle_marker_2_.header.frame_id = "vec_drive2";
            vehicle_marker_2_.header.stamp = ros::Time(0);
            vehicle_marker_2_.ns = "vehicle";
            vehicle_marker_2_.action = visualization_msgs::Marker::ADD;
            vehicle_marker_2_.id = 2;
            vehicle_marker_2_.type = visualization_msgs::Marker::MESH_RESOURCE; 
            string mesh_resource_2 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";
            vehicle_marker_2_.scale.x = 0.003;
            vehicle_marker_2_.scale.y = 0.003;
            vehicle_marker_2_.scale.z = 0.003;
            vehicle_marker_2_.color.r = 0.85;//1
            vehicle_marker_2_.color.g = 0.64;//0.5
            vehicle_marker_2_.color.b = 0.12;  //0
            vehicle_marker_2_.color.a = 1;
            vehicle_marker_2_.mesh_resource = mesh_resource_2;
            vehicle_marker_2_.pose.position.x = 0;
            vehicle_marker_2_.pose.position.y = 0;
            vehicle_marker_2_.pose.position.z = 0;
            geometry_msgs::Quaternion temp_q2 = tf::createQuaternionMsgFromYaw(now_yaw_2);
            vehicle_marker_2_.pose.orientation.x = temp_q2.x;
            vehicle_marker_2_.pose.orientation.y = temp_q2.y;
            vehicle_marker_2_.pose.orientation.z = temp_q2.z;
            vehicle_marker_2_.pose.orientation.w = temp_q2.w;
            pubVehicle2.publish(vehicle_marker_2_);
            my_transform2.setOrigin(tf::Vector3(now_x_2,now_y_2,0));
            br2.sendTransform(tf::StampedTransform(my_transform2,ros::Time::now(),"tracksim_pub","vec_drive2"));
        }

        //车辆3发布
        if(1){
            static tf::TransformBroadcaster br3; //需要修改变量名 br2
            tf::Transform my_transform3; //需要修改变量名 my_transform2
            tf::Quaternion q3;          //需要修改变量名 q2
            q3.setRPY(0,0,0);           //需要修改变量名 q2
            my_transform3.setRotation(q3);  //需要修改变量名   my_transform2 q2
            vehicle_marker_3_.header.frame_id = "vec_drive3";    //需要修改变量名 vehicle_marker_2_ "vec_drive2"
            vehicle_marker_3_.header.stamp = ros::Time(0);      //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.ns = "vehicle";                    //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.action = visualization_msgs::Marker::ADD;   //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.id = 3;                                      //需要修改变量名 vehicle_marker_2_ id=2
            vehicle_marker_3_.type = visualization_msgs::Marker::MESH_RESOURCE;   //需要修改变量名 vehicle_marker_2_
            string mesh_resource_3 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";  //需要修改变量名 mesh_resource_2
            vehicle_marker_3_.scale.x = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.scale.y = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.scale.z = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.color.r = 0.85;//1  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.color.g = 0.64;//0.5  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.color.b = 0.12;  //0  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.color.a = 1;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.mesh_resource = mesh_resource_3;   //需要修改变量名 vehicle_marker_2_ mesh_resource_2
            vehicle_marker_3_.pose.position.x = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.pose.position.y = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_3_.pose.position.z = 0;  //需要修改变量名 vehicle_marker_2_
            geometry_msgs::Quaternion temp_q3 = tf::createQuaternionMsgFromYaw(now_yaw_3); //需要修改变量名 temp_q2 now_yaw_2
            vehicle_marker_3_.pose.orientation.x = temp_q3.x;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_3_.pose.orientation.y = temp_q3.y;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_3_.pose.orientation.z = temp_q3.z;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_3_.pose.orientation.w = temp_q3.w;  //需要修改变量名 vehicle_marker_2_  temp_q2
            pubVehicle3.publish(vehicle_marker_3_);  //需要修改变量名 vehicle_marker_2_  pubVehicle2
            my_transform3.setOrigin(tf::Vector3(now_x_3,now_y_3,0));  //需要修改变量名 my_transform2  now_x_2 now_y_2
            br3.sendTransform(tf::StampedTransform(my_transform3,ros::Time::now(),"tracksim_pub","vec_drive3")); //需要修改变量名 br2  my_transform2 "vec_drive2"
        }

        //车辆4发布
        if(1){
            static tf::TransformBroadcaster br4; //需要修改变量名 br2
            tf::Transform my_transform4; //需要修改变量名 my_transform2
            tf::Quaternion q4;          //需要修改变量名 q2
            q4.setRPY(0,0,0);           //需要修改变量名 q2
            my_transform4.setRotation(q4);  //需要修改变量名   my_transform2 q2
            vehicle_marker_4_.header.frame_id = "vec_drive4";    //需要修改变量名 vehicle_marker_2_ "vec_drive2"
            vehicle_marker_4_.header.stamp = ros::Time(0);      //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.ns = "vehicle";                    //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.action = visualization_msgs::Marker::ADD;   //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.id = 4;                                      //需要修改变量名 vehicle_marker_2_ id=2
            vehicle_marker_4_.type = visualization_msgs::Marker::MESH_RESOURCE;   //需要修改变量名 vehicle_marker_2_
            string mesh_resource_4 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";  //需要修改变量名 mesh_resource_2
            vehicle_marker_4_.scale.x = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.scale.y = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.scale.z = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.color.r = 0.85;//1  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.color.g = 0.64;//0.5  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.color.b = 0.12;  //0  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.color.a = 1;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.mesh_resource = mesh_resource_4;   //需要修改变量名 vehicle_marker_2_ mesh_resource_2
            vehicle_marker_4_.pose.position.x = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.pose.position.y = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_4_.pose.position.z = 0;  //需要修改变量名 vehicle_marker_2_
            geometry_msgs::Quaternion temp_q4 = tf::createQuaternionMsgFromYaw(now_yaw_4); //需要修改变量名 temp_q2 now_yaw_2
            vehicle_marker_4_.pose.orientation.x = temp_q4.x;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_4_.pose.orientation.y = temp_q4.y;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_4_.pose.orientation.z = temp_q4.z;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_4_.pose.orientation.w = temp_q4.w;  //需要修改变量名 vehicle_marker_2_  temp_q2
            pubVehicle4.publish(vehicle_marker_4_);  //需要修改变量名 vehicle_marker_2_  pubVehicle2
            my_transform4.setOrigin(tf::Vector3(now_x_4,now_y_4,0));  //需要修改变量名 my_transform2  now_x_2 now_y_2
            br4.sendTransform(tf::StampedTransform(my_transform4,ros::Time::now(),"tracksim_pub","vec_drive4")); //需要修改变量名 br2  my_transform2 "vec_drive2"
        }

        //车辆5发布
        if(1){
            static tf::TransformBroadcaster br5; //需要修改变量名 br2
            tf::Transform my_transform5; //需要修改变量名 my_transform2
            tf::Quaternion q5;          //需要修改变量名 q2
            q5.setRPY(0,0,0);           //需要修改变量名 q2
            my_transform5.setRotation(q5);  //需要修改变量名   my_transform2 q2
            vehicle_marker_5_.header.frame_id = "vec_drive5";    //需要修改变量名 vehicle_marker_2_ "vec_drive2"
            vehicle_marker_5_.header.stamp = ros::Time(0);      //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.ns = "vehicle";                    //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.action = visualization_msgs::Marker::ADD;   //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.id = 5;                                      //需要修改变量名 vehicle_marker_2_ id=2
            vehicle_marker_5_.type = visualization_msgs::Marker::MESH_RESOURCE;   //需要修改变量名 vehicle_marker_2_
            string mesh_resource_5 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";  //需要修改变量名 mesh_resource_2
            vehicle_marker_5_.scale.x = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.scale.y = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.scale.z = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.color.r = 0.85;//1  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.color.g = 0.64;//0.5  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.color.b = 0.12;  //0  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.color.a = 1;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.mesh_resource = mesh_resource_5;   //需要修改变量名 vehicle_marker_2_ mesh_resource_2
            vehicle_marker_5_.pose.position.x = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.pose.position.y = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_5_.pose.position.z = 0;  //需要修改变量名 vehicle_marker_2_
            geometry_msgs::Quaternion temp_q5 = tf::createQuaternionMsgFromYaw(now_yaw_5); //需要修改变量名 temp_q2 now_yaw_2
            vehicle_marker_5_.pose.orientation.x = temp_q5.x;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_5_.pose.orientation.y = temp_q5.y;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_5_.pose.orientation.z = temp_q5.z;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_5_.pose.orientation.w = temp_q5.w;  //需要修改变量名 vehicle_marker_2_  temp_q2
            pubVehicle5.publish(vehicle_marker_5_);  //需要修改变量名 vehicle_marker_2_  pubVehicle2
            my_transform5.setOrigin(tf::Vector3(now_x_5,now_y_5,0));  //需要修改变量名 my_transform2  now_x_2 now_y_2
            br5.sendTransform(tf::StampedTransform(my_transform5,ros::Time::now(),"tracksim_pub","vec_drive5")); //需要修改变量名 br2  my_transform2 "vec_drive2"
        }

        //车辆6发布
        if(1){
            static tf::TransformBroadcaster br6; //需要修改变量名 br2
            tf::Transform my_transform6; //需要修改变量名 my_transform2
            tf::Quaternion q6;          //需要修改变量名 q2
            q6.setRPY(0,0,0);           //需要修改变量名 q2
            my_transform6.setRotation(q6);  //需要修改变量名   my_transform2 q2
            vehicle_marker_6_.header.frame_id = "vec_drive6";    //需要修改变量名 vehicle_marker_2_ "vec_drive2"
            vehicle_marker_6_.header.stamp = ros::Time(0);      //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.ns = "vehicle";                    //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.action = visualization_msgs::Marker::ADD;   //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.id = 6;                                      //需要修改变量名 vehicle_marker_2_ id=2
            vehicle_marker_6_.type = visualization_msgs::Marker::MESH_RESOURCE;   //需要修改变量名 vehicle_marker_2_
            string mesh_resource_6 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";  //需要修改变量名 mesh_resource_2
            vehicle_marker_6_.scale.x = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.scale.y = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.scale.z = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.color.r = 0.85;//1  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.color.g = 0.64;//0.5  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.color.b = 0.12;  //0  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.color.a = 1;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.mesh_resource = mesh_resource_6;   //需要修改变量名 vehicle_marker_2_ mesh_resource_2
            vehicle_marker_6_.pose.position.x = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.pose.position.y = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_6_.pose.position.z = 0;  //需要修改变量名 vehicle_marker_2_
            geometry_msgs::Quaternion temp_q6 = tf::createQuaternionMsgFromYaw(now_yaw_6); //需要修改变量名 temp_q2 now_yaw_2
            vehicle_marker_6_.pose.orientation.x = temp_q6.x;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_6_.pose.orientation.y = temp_q6.y;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_6_.pose.orientation.z = temp_q6.z;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_6_.pose.orientation.w = temp_q6.w;  //需要修改变量名 vehicle_marker_2_  temp_q2
            pubVehicle6.publish(vehicle_marker_6_);  //需要修改变量名 vehicle_marker_2_  pubVehicle2
            my_transform6.setOrigin(tf::Vector3(now_x_6,now_y_6,0));  //需要修改变量名 my_transform2  now_x_2 now_y_2
            br6.sendTransform(tf::StampedTransform(my_transform6,ros::Time::now(),"tracksim_pub","vec_drive6")); //需要修改变量名 br2  my_transform2 "vec_drive2"
        }

        //车辆7发布
        if(1){
            static tf::TransformBroadcaster br7; //需要修改变量名 br2
            tf::Transform my_transform7; //需要修改变量名 my_transform2
            tf::Quaternion q7;          //需要修改变量名 q2
            q7.setRPY(0,0,0);           //需要修改变量名 q2
            my_transform7.setRotation(q7);  //需要修改变量名   my_transform2 q2
            vehicle_marker_7_.header.frame_id = "vec_drive7";    //需要修改变量名 vehicle_marker_2_ "vec_drive2"
            vehicle_marker_7_.header.stamp = ros::Time(0);      //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.ns = "vehicle";                    //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.action = visualization_msgs::Marker::ADD;   //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.id = 7;                                      //需要修改变量名 vehicle_marker_2_ id=2
            vehicle_marker_7_.type = visualization_msgs::Marker::MESH_RESOURCE;   //需要修改变量名 vehicle_marker_2_
            string mesh_resource_7 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";  //需要修改变量名 mesh_resource_2
            vehicle_marker_7_.scale.x = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.scale.y = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.scale.z = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.color.r = 0.85;//1  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.color.g = 0.64;//0.5  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.color.b = 0.12;  //0  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.color.a = 1;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.mesh_resource = mesh_resource_7;   //需要修改变量名 vehicle_marker_2_ mesh_resource_2
            vehicle_marker_7_.pose.position.x = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.pose.position.y = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_7_.pose.position.z = 0;  //需要修改变量名 vehicle_marker_2_
            geometry_msgs::Quaternion temp_q7 = tf::createQuaternionMsgFromYaw(now_yaw_7); //需要修改变量名 temp_q2 now_yaw_2
            vehicle_marker_7_.pose.orientation.x = temp_q7.x;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_7_.pose.orientation.y = temp_q7.y;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_7_.pose.orientation.z = temp_q7.z;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_7_.pose.orientation.w = temp_q7.w;  //需要修改变量名 vehicle_marker_2_  temp_q2
            pubVehicle7.publish(vehicle_marker_7_);  //需要修改变量名 vehicle_marker_2_  pubVehicle2
            my_transform7.setOrigin(tf::Vector3(now_x_7,now_y_7,0));  //需要修改变量名 my_transform2  now_x_2 now_y_2
            br7.sendTransform(tf::StampedTransform(my_transform7,ros::Time::now(),"tracksim_pub","vec_drive7")); //需要修改变量名 br2  my_transform2 "vec_drive2"
        }

        //车辆8发布
        if(1){
            static tf::TransformBroadcaster br8; //需要修改变量名 br2
            tf::Transform my_transform8; //需要修改变量名 my_transform2
            tf::Quaternion q8;          //需要修改变量名 q2
            q8.setRPY(0,0,0);           //需要修改变量名 q2
            my_transform8.setRotation(q8);  //需要修改变量名   my_transform2 q2
            vehicle_marker_8_.header.frame_id = "vec_drive8";    //需要修改变量名 vehicle_marker_2_ "vec_drive2"
            vehicle_marker_8_.header.stamp = ros::Time(0);      //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.ns = "vehicle";                    //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.action = visualization_msgs::Marker::ADD;   //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.id = 8;                                      //需要修改变量名 vehicle_marker_2_ id=2
            vehicle_marker_8_.type = visualization_msgs::Marker::MESH_RESOURCE;   //需要修改变量名 vehicle_marker_2_
            string mesh_resource_8 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";  //需要修改变量名 mesh_resource_2
            vehicle_marker_8_.scale.x = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.scale.y = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.scale.z = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.color.r = 0.85;//1  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.color.g = 0.64;//0.5  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.color.b = 0.12;  //0  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.color.a = 1;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.mesh_resource = mesh_resource_8;   //需要修改变量名 vehicle_marker_2_ mesh_resource_2
            vehicle_marker_8_.pose.position.x = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.pose.position.y = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_8_.pose.position.z = 0;  //需要修改变量名 vehicle_marker_2_
            geometry_msgs::Quaternion temp_q8 = tf::createQuaternionMsgFromYaw(now_yaw_8); //需要修改变量名 temp_q2 now_yaw_2
            vehicle_marker_8_.pose.orientation.x = temp_q8.x;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_8_.pose.orientation.y = temp_q8.y;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_8_.pose.orientation.z = temp_q8.z;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_8_.pose.orientation.w = temp_q8.w;  //需要修改变量名 vehicle_marker_2_  temp_q2
            pubVehicle8.publish(vehicle_marker_8_);  //需要修改变量名 vehicle_marker_2_  pubVehicle2
            my_transform8.setOrigin(tf::Vector3(now_x_8,now_y_8,0));  //需要修改变量名 my_transform2  now_x_2 now_y_2
            br8.sendTransform(tf::StampedTransform(my_transform8,ros::Time::now(),"tracksim_pub","vec_drive8")); //需要修改变量名 br2  my_transform2 "vec_drive2"
        }

        //车辆9发布
        if(1){
            static tf::TransformBroadcaster br9; //需要修改变量名 br2
            tf::Transform my_transform9; //需要修改变量名 my_transform2
            tf::Quaternion q9;          //需要修改变量名 q2
            q9.setRPY(0,0,0);           //需要修改变量名 q2
            my_transform9.setRotation(q9);  //需要修改变量名   my_transform2 q2
            vehicle_marker_9_.header.frame_id = "vec_drive9";    //需要修改变量名 vehicle_marker_2_ "vec_drive2"
            vehicle_marker_9_.header.stamp = ros::Time(0);      //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.ns = "vehicle";                    //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.action = visualization_msgs::Marker::ADD;   //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.id = 9;                                      //需要修改变量名 vehicle_marker_2_ id=2
            vehicle_marker_9_.type = visualization_msgs::Marker::MESH_RESOURCE;   //需要修改变量名 vehicle_marker_2_
            string mesh_resource_9 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";  //需要修改变量名 mesh_resource_2
            vehicle_marker_9_.scale.x = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.scale.y = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.scale.z = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.color.r = 0.85;//1  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.color.g = 0.64;//0.5  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.color.b = 0.12;  //0  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.color.a = 1;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.mesh_resource = mesh_resource_9;   //需要修改变量名 vehicle_marker_2_ mesh_resource_2
            vehicle_marker_9_.pose.position.x = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.pose.position.y = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_9_.pose.position.z = 0;  //需要修改变量名 vehicle_marker_2_
            geometry_msgs::Quaternion temp_q9 = tf::createQuaternionMsgFromYaw(now_yaw_9); //需要修改变量名 temp_q2 now_yaw_2
            vehicle_marker_9_.pose.orientation.x = temp_q9.x;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_9_.pose.orientation.y = temp_q9.y;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_9_.pose.orientation.z = temp_q9.z;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_9_.pose.orientation.w = temp_q9.w;  //需要修改变量名 vehicle_marker_2_  temp_q2
            pubVehicle9.publish(vehicle_marker_9_);  //需要修改变量名 vehicle_marker_2_  pubVehicle2
            my_transform9.setOrigin(tf::Vector3(now_x_9,now_y_9,0));  //需要修改变量名 my_transform2  now_x_2 now_y_2
            br9.sendTransform(tf::StampedTransform(my_transform9,ros::Time::now(),"tracksim_pub","vec_drive9")); //需要修改变量名 br2  my_transform2 "vec_drive2"
        }

        //车辆10发布
        if(1){
            static tf::TransformBroadcaster br10; //需要修改变量名 br2
            tf::Transform my_transform10; //需要修改变量名 my_transform2
            tf::Quaternion q10;          //需要修改变量名 q2
            q10.setRPY(0,0,0);           //需要修改变量名 q2
            my_transform10.setRotation(q10);  //需要修改变量名   my_transform2 q2
            vehicle_marker_10_.header.frame_id = "vec_drive10";    //需要修改变量名 vehicle_marker_2_ "vec_drive2"
            vehicle_marker_10_.header.stamp = ros::Time(0);      //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.ns = "vehicle";                    //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.action = visualization_msgs::Marker::ADD;   //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.id = 10;                                      //需要修改变量名 vehicle_marker_2_ id=2
            vehicle_marker_10_.type = visualization_msgs::Marker::MESH_RESOURCE;   //需要修改变量名 vehicle_marker_2_
            string mesh_resource_10 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";  //需要修改变量名 mesh_resource_2
            vehicle_marker_10_.scale.x = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.scale.y = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.scale.z = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.color.r = 0.85;//1  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.color.g = 0.64;//0.5  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.color.b = 0.12;  //0  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.color.a = 1;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.mesh_resource = mesh_resource_10;   //需要修改变量名 vehicle_marker_2_ mesh_resource_2
            vehicle_marker_10_.pose.position.x = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.pose.position.y = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_10_.pose.position.z = 0;  //需要修改变量名 vehicle_marker_2_
            geometry_msgs::Quaternion temp_q10 = tf::createQuaternionMsgFromYaw(now_yaw_10); //需要修改变量名 temp_q2 now_yaw_2
            vehicle_marker_10_.pose.orientation.x = temp_q10.x;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_10_.pose.orientation.y = temp_q10.y;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_10_.pose.orientation.z = temp_q10.z;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_10_.pose.orientation.w = temp_q10.w;  //需要修改变量名 vehicle_marker_2_  temp_q2
            pubVehicle10.publish(vehicle_marker_10_);  //需要修改变量名 vehicle_marker_2_  pubVehicle2
            my_transform10.setOrigin(tf::Vector3(now_x_10,now_y_10,0));  //需要修改变量名 my_transform2  now_x_2 now_y_2
            br10.sendTransform(tf::StampedTransform(my_transform10,ros::Time::now(),"tracksim_pub","vec_drive10")); //需要修改变量名 br2  my_transform2 "vec_drive2"
        }

        //车辆11发布
        if(1){
            static tf::TransformBroadcaster br11; //需要修改变量名 br2
            tf::Transform my_transform11; //需要修改变量名 my_transform2
            tf::Quaternion q11;          //需要修改变量名 q2
            q11.setRPY(0,0,0);           //需要修改变量名 q2
            my_transform11.setRotation(q11);  //需要修改变量名   my_transform2 q2
            vehicle_marker_11_.header.frame_id = "vec_drive11";    //需要修改变量名 vehicle_marker_2_ "vec_drive2"
            vehicle_marker_11_.header.stamp = ros::Time(0);      //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.ns = "vehicle";                    //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.action = visualization_msgs::Marker::ADD;   //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.id = 11;                                      //需要修改变量名 vehicle_marker_2_ id=2
            vehicle_marker_11_.type = visualization_msgs::Marker::MESH_RESOURCE;   //需要修改变量名 vehicle_marker_2_
            string mesh_resource_11 = "package://rviz_simulation/model/16747_Mining_Truck_v1.obj";  //需要修改变量名 mesh_resource_2
            vehicle_marker_11_.scale.x = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.scale.y = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.scale.z = 0.003;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.color.r = 0.85;//1  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.color.g = 0.64;//0.5  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.color.b = 0.12;  //0  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.color.a = 1;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.mesh_resource = mesh_resource_11;   //需要修改变量名 vehicle_marker_2_ mesh_resource_2
            vehicle_marker_11_.pose.position.x = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.pose.position.y = 0;  //需要修改变量名 vehicle_marker_2_
            vehicle_marker_11_.pose.position.z = 0;  //需要修改变量名 vehicle_marker_2_
            geometry_msgs::Quaternion temp_q11 = tf::createQuaternionMsgFromYaw(now_yaw_11); //需要修改变量名 temp_q2 now_yaw_2
            vehicle_marker_11_.pose.orientation.x = temp_q11.x;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_11_.pose.orientation.y = temp_q11.y;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_11_.pose.orientation.z = temp_q11.z;  //需要修改变量名 vehicle_marker_2_  temp_q2
            vehicle_marker_11_.pose.orientation.w = temp_q11.w;  //需要修改变量名 vehicle_marker_2_  temp_q2
            pubVehicle11.publish(vehicle_marker_11_);  //需要修改变量名 vehicle_marker_2_  pubVehicle2
            my_transform11.setOrigin(tf::Vector3(now_x_11,now_y_11,0));  //需要修改变量名 my_transform2  now_x_2 now_y_2
            br11.sendTransform(tf::StampedTransform(my_transform11,ros::Time::now(),"tracksim_pub","vec_drive11")); //需要修改变量名 br2  my_transform2 "vec_drive2"
        }


        ros::spinOnce();
        loop_rate.sleep();
    }

    return 0;
}
